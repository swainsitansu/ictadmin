package com.six.admin.api;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.six.admin.service.UserService;
import com.six.admin.util.UserMapper;
import com.six.api.UserApiDelegate;
import com.six.model.UserModel;

@Service
public class UserDelegateImpl implements UserApiDelegate {

    @Autowired
    private UserService userService;

    @Override
    public ResponseEntity<List<UserModel>> allUsers() {
        List<UserModel> collect = userService.getAllUsers().stream().map(user -> UserMapper.UserEntityToUserModel(user)).collect(Collectors.toList());
        return new ResponseEntity<>(collect, HttpStatus.OK);
    }
}
