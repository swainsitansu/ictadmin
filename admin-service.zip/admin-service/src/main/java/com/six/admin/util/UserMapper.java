package com.six.admin.util;

import com.six.admin.entities.User;
import com.six.model.UserModel;
import lombok.Builder;

@Builder
public class UserMapper {

    public static User UserModelToUserEntity(UserModel userModel){
        User user = new User();
        user.setUserName(userModel.getUsername());
        user.setFirstName(userModel.getFirstName());
        user.setLastName(userModel.getLastName());
        user.setEmail(userModel.getEmail());
        user.setUserStatus(userModel.getUserStatus());
        user.setPhone(userModel.getPhone());
        user.setId(userModel.getId());

        return user;
    }

    public static UserModel UserEntityToUserModel(User user){
        UserModel userModel = new UserModel();
        userModel.setUsername(user.getUserName());
        userModel.setFirstName(user.getFirstName());
        userModel.setLastName(user.getLastName());
        userModel.setEmail(user.getEmail());
        userModel.setUserStatus(user.getUserStatus());
        userModel.setPhone(user.getPhone());
        userModel.setId(user.getId());

        return userModel;
    }

}
