package com.six.admin.service;

import org.springframework.stereotype.Service;

import com.six.admin.entities.User;

import java.util.Arrays;
import java.util.List;

@Service
public class UserServiceImpl implements UserService{

    @Override
    public List<User> getAllUsers() {
        return Arrays.asList(
                User.builder().id(101L).userName("ssa").firstName("syed").lastName("saqib").userStatus(1).email("ssa@gmail.com").phone("8105036587").build(),
                User.builder().id(101L).userName("vvk").firstName("virat").lastName("kohli").userStatus(1).email("virat@gmail.com").phone("479827382").build(),
                User.builder().id(101L).userName("gml").firstName("glenn").lastName("maxwell").userStatus(1).email("glen@gmail.com").phone("98732929").build()
                );
    }
}
