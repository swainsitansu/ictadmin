package com.six.admin.controller;

import com.six.api.UserApi;
import com.six.api.UserApiDelegate;
import com.six.model.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController implements UserApi {

    @Autowired
    private UserApiDelegate userApiDelegate;

    @Override
    public ResponseEntity<List<UserModel>> allUsers() {
        return userApiDelegate.allUsers();
    }
}
