package com.six.admin.entities;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
@Data
public class User {

    private Long id;

    private String userName;

    private String firstName;

    private String lastName;

    private String email;

    private String phone;

    private Integer userStatus;
}
