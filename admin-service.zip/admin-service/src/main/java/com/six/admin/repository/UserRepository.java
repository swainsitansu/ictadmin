package com.six.admin.repository;

public interface UserRepository {
}
