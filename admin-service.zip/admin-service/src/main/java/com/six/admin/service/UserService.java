package com.six.admin.service;

import java.util.List;

import com.six.admin.entities.User;

public interface UserService {

    List<User> getAllUsers();
}
